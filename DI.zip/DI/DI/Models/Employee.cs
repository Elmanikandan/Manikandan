﻿namespace DI.Models
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string Department { get; set; }
        public string Unit { get; set; }
        public string Gender { get; set; }
    }
}
