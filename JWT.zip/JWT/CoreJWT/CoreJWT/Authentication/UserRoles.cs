﻿namespace CoreJWT.Authentication
{
    public class UserRoles
    {
        public const string user = "User";
        public const string Admin = "Admin";
    }
}
