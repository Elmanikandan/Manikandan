﻿using Microsoft.AspNetCore.Identity;

namespace CoreJWT.Authentication
{
    public class ApplicationUser : IdentityUser
    {
    }
}
